<?php
include("config.php");
session_start();
if (!isset($_SESSION['login_id'])) {
	header('Location: login.php');
}

	$todoid=isset($_GET['todoid'])?$_GET['todoid']:'';
	// echo $todoid; die();


	// $user_id=$_SESSION['login_id'];
 //    $id= $_POST['id'];
	// echo $txttitle= $_POST['txttitle'];
	//echo $id;


    $show_query="SELECT todo.title_id,title.title_name,todo.todo_name,todo.start_date,todo.end_date,todo.bg_color,todo.title_id FROM todo INNER JOIN title ON todo.title_id=title.title_id WHERE todo_id='$todoid'";
    $show_results=mysqli_query($link,$show_query);
    $rows = mysqli_fetch_array($show_results);

    $titleid=$rows['title_id'];
    $title_name=$rows['title_name'];
    $todo =$rows['todo_name'];

    // $filename =$rows['filename'];
    $start_date=$rows['start_date'];
    $end_date =$rows['end_date'];
    // $radio=$rows['bg_color'];
    // echo $start_date;
    // echo $end_date;
    // die();
// submit update
if(isset($_POST['btnUpdate'])) {
		$tid=$_POST['id'];
		//echo $tid;
		$title_id=$_POST['titleid'];
		$todo=$_POST['todo'];


		// $img=$_POST['img'];
		//  $temp = explode(".", $_FILES["file"]["name"]);
		// $name = pathinfo($_FILES["file"]["name"],PATHINFO_FILENAME);
		// $extension = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
		// $i = 0;
		// if (!empty($_FILES["file"])) {
		// 			//echo "hello";
		// 			  if ($_FILES["file"]["error"] > 0) {
		// 				echo "Return Code: " . $_FILES["file"]["error"] . "<br>";
		// 			  }else{
		// 					$basename = time().'_'.$_FILES["file"]["name"];// . $i . '.' . $extension;
		// 					move_uploaded_file($_FILES["file"]["tmp_name"],"images/" . $basename);
		// 			  }
		// } 
		// $img=$_FILES["file"]["name"];
		$startdate=$_POST['start_date'];
		$enddate=$_POST['end_date'];
		// $color=$_POST['color'];
		$sdate = str_replace('/', '-', $startdate );
		$sd = date("Y-m-d", strtotime($sdate));

		$edate = str_replace('/', '-', $enddate );
		$ed = date("Y-m-d", strtotime($edate));
		// print_r($sd);
		// print_r($ed);
		// die();


			if(empty($title_id) && empty($todo) && empty($basename) && empty($sd) && empty($ed) 
				&& empty($radio)){
				echo "<div class='error-messages'>Choose title Name</div>";
				echo "<div class='error-messages'>Choose todo name</div>";
				// echo "<div class='error-messages'>Please upload image</div>";
				echo "<div class='error-messages'>Enter start date</div>";
				echo "<div class='error-messages'>Enter end date</div>";
				echo "<div class='error-messages'>Choose color</div>";
			}
			else if(empty($title_id)){
				echo "<div class='error-messages'>Choose title Name</div>";
			}else if(empty($todo)){
				echo "<div class='error-messages'>Enter todo name</div>";
			}else if($startdate>$enddate){
				echo "<div class='error-messages'>Start date is greater than end date.</div>";
			}else if(empty($sd)){
				echo "<div class='error-messages'>Enter start date</div>";
			}else if(empty($ed)){
				echo "<div class='error-messages'>Enter end date</div>";
			}
			// else if(empty($radio)){
			// 	echo "<div class='error-messages'>Choose color</div>";
			// }
			else{
				$sql="UPDATE todo SET title_id='$tid', todo_name='$todo',start_date='$sd',end_date='$ed' WHERE todo_id='$tid'";
				   // echo $sql;die();
				   // echo $_FILES["file"]["name"];die();
				mysqli_multi_query($link, $sql);
				// $_SESSION['img']=$_FILES["file"]["name"];
				$_SESSION['success']="Updated Successfully!";
				header('Location: showtodo.php');
			}
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Title insert</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link type="text/css" href="css/ui-lightness/jquery-ui-1.8.19.custom.css" rel="stylesheet" />
	<script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
	<script type="text/javascript" src="js/jquery-ui-1.8.19.custom.min.js"></script>
	<script src="js/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="css/jquery.datetimepicker.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/todo.css"/>
	<script src="js/jquery.datetimepicker.js"></script>
	<script type="text/javascript">
			$(document).ready(function () {
				$('#datepicker1').datetimepicker();
				$('#datepicker2').datetimepicker();
			});
	</script>
	<style type="text/css">
			.ui-datepicker { font-size:8pt !important}
	</style>
</head>
<body>
  <h2>Todo Update</h2>
	<form action="update_todo_tr.php" method="post" enctype="multipart/form-data">
		  <div class="container">
				<label for="title"><b>Title Name</b></label>
				<?php
				$sql="SELECT title_id,title_name FROM title";
				echo "<select name='title_name' class='title_name' id='title_name' onchange='updateValue();'  value='".$tn=isset($_POST['title_name'])?$_POST['title_name']:''."'>";
				echo "<option value='".$_POST['title_name']."' disabled selected>Select One</option>"; 
				$results=mysqli_query($link,$sql);
				foreach ($results as $row): ?>
					<option value="<?=$row['title_id'];?>" <?php if ($row['title_name'] == $title_name) { echo 'selected'; } ?>><?=$row['title_name']?></option> 
				<?php endforeach; ?>
				</select>
				<input type="hidden" name="id" id="id" value="<?php echo $todoid; ?>">
				<input type="hidden" name="titleid" id="titleid" value="<?php echo $title_id; ?>">
				<label for="todo"><b>Todo Name</b></label>
				<input class="todoinsert" type="text" placeholder="Enter Todo Name" name="todo" id="todo" value="<?php echo $todo; ?>" >
				<label for="start_date"><b>Start Date</b></label>
				<input class="todoinsert" type="text" id="datepicker1" name="start_date"  value="<?php echo $start_date;?>" />
				<label for="end_date"><b>End Date</b></label>
				<input class="todoinsert" type="text" id="datepicker2" name="end_date" value="<?php echo $end_date;?>" />
				
				<input class="todobutton" type="submit" name="btnUpdate" id="btnUpdate" value="Update">
				<a href="showtodo.php"><input class="todobutton" type="button" name="btnback" id="btnback" value="Back" onclick="back()"></a>
		  </div>
	</form>
	<!-- 	document.getElementById("color").value = e.target.value
	} -->
</body>
<script type="text/javascript">
	// document.getElementById("color").value = e.target.value
	// }

	function back(){
	  location.href = "showtodo.php";
	} 
	// function	myFunction(e) {
	// 	 document.getElementById("color").value = e.target.value
	// }
	function myFunction(e) {
		document.getElementById("title").value = e.target.value
	}
	function myFunction1(e) {
	$("#todo,#datepicker1,#datepicker2").keypress(function(e) {
	  //Enter key
	  if (e.which == 13) {
		return false;
	  }
	});
	/* auto complete of title name select box*/
	function updateValue(){
		$('#titleid').val($('#title_name').val());
	}
	$(document).ready(function () {
		updateValue();
	});
</script>
</html>