<?php
include("config.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body style="background-color:#02d5fa;">
<form action="titleshow.php" method="post">
<h1 align="center">Title Show Page</h1>
	<table align="center">
		<tr>

			<td><label>Title</label></td>
			<td><input type="text" name="txttitle" id="txttitle"></td>

			<td><input type="submit" name="btnsearch" id="btnsearch" value="Search"></td>

			<td><a href="titleshow.php"><input type="button" name="btnclear" id="btnclear" value="Clear"></a></td>

			<td><a href="title_insert_page.php"><input type="button" name="btninsert" id="btninsert" value="Insert"></a></td>

			<td><input type="button" value="Back" onclick="history.back()"></td>

		</tr>
	</table>

	<br>



	<?php
	if(isset($_POST["btnsearch"])){
		$title=$_POST["txttitle"];

		if($title!=""){?>
			<table border="1" width="100%">

		<tr>
			<th>No</th>
			<th>Name</th>
			<th>Create User</th>
			<th>Create Date</th>
		</tr>
		<?php
			$sql="SELECT * FROM title WHERE title_name LIKE '%$title%'";
			$result= mysqli_query($link,$sql);

			while ($data=mysqli_fetch_array($result)) {
				?>

			<tr>
					<td><?php echo $data['title_id'];?></td>
					<td><?php echo $data['title_name'];?></td>
					<td><?php echo $data['create_user'];?></td>
					<td><?php echo $data['create_date'];?></td>
			</tr>




			
			<?php }?>


	
	</table>









<?php } else{ ?>

<table border="1" width="100%">

	<tr>
			<th>No</th>
			<th>Name</th>
			<th>Create User</th>
			<th>Create Date</th>
		</tr>

	<?php
			$query="SELECT title_id,title_name,create_user,create_date FROM title";
			$result= mysqli_query($link,$query);

			while ($data=mysqli_fetch_array($result)) {
		?>

				<tr>
					<td><?php echo $data['title_id'];?></td>
					<td><?php echo $data['title_name'];?></td>
					<td><?php echo $data['create_user'];?></td>
					<td><?php echo $data['create_date'];?></td>
				</tr>

			
				<?php 
						}

				?>

			
	</table>


	<?php }  ?>





		<?php } else {?>

				<table border="1" width="100%">

		<tr>
			<th>No</th>
			<th>Name</th>
			<th>Create User</th>
			<th>Create Date</th>
		</tr>

	
		<?php
			$query="SELECT title_id,title_name,create_user,create_date FROM title";
			$result= mysqli_query($link,$query);

			while ($data=mysqli_fetch_array($result)) {
		?>

			
				<tr>
					<td><?php echo $data['title_id'];?></td>
					<td><?php echo $data['title_name'];?></td>
					<td><?php echo $data['create_user'];?></td>
					<td><?php echo $data['create_date'];?></td>
				</tr>




			
			<?php } ?>


	
	</table>

<?php }?>


</form>

</body>
</html>