$(document).ready(function(){
$("#btnClear").click(function(){
var title = $("#txttitle").val();
var start_date=$("#datepicker1").val();
var end_date=$("#datepicker2").val();
// Returns successful data submission message when the entered information is stored in database.
var dataString = 'title1='+ title+'&start='+start_date+'&end='+end_date;
$('#txttitle').val('');
 // $('#showtitle').html("Loading...");
$.ajax({
type: "POST",
url: "cleartodo.php",
data: dataString,
cache: false,
success: function(result){
 //alert(result);
$("#todo").remove();
$(".todolist").append(result);
}
});
return false;
});
});