$(document).ready(function(){
$("#btnClear").click(function(){
var title = $("#txttitle").val();
// Returns successful data submission message when the entered information is stored in database.
var dataString = 'title1='+ title;
$('#txttitle').val('');
 // $('#showtitle').html("Loading...");
$.ajax({
type: "POST",
url: "cleartitle.php",
data: dataString,
cache: false,
success: function(result){
// alert(result);
$("#showtitle").remove();
$(".txt").append(result);
}
});
return false;
});
});