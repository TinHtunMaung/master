<?php
include("config.php");

$todoid=isset($_GET['todoid'])?$_GET['todoid']:'';
	// echo $todoid;die();
$select_todo_query="SELECT title.title_id,title.title_name,todo.todo_name,todo.start_date,todo.end_date,todo.bg_color,todo.delete_flag FROM todo INNER JOIN title ON title.title_id=todo.title_id WHERE todo_id='$todoid'";
// echo $select_todo_query;die();
$result_todo_data=mysqli_query($link,$select_todo_query);
$row=mysqli_fetch_array($result_todo_data);


	if(isset($_POST['btnup'])) {
	$titlename=$_POST["txttitlename"];
	$todoname=$_POST["txttodoname"];
	$startdate=$_POST["txtstartdate"];
	$enddate=$_POST["txtenddate"];
	$bg_color=$_POST["color"];


    }else{


// 	$sql1 = "UPDATE title,todo
// 	JOIN title ON title.title_id = todo.title_id
// 	SET title.title_name=todo.title_name, todo.todo_name,
// 	todo.start_date, todo.end_date,todo.bg_color 
// 	WHERE todo.title_id= title.title_id";
// 	echo $sql1; die();
// 	mysqli_multi_query($link, $sql1);



//     	$sql1 = "UPDATE todo
//     	SET (SELECT title.title_name,todo.todo_name,todo.start_date,todo.end_date,todo.bg_color,todo.delete_flag FROM todo INNER JOIN title ON title.title_id=todo.title_id WHERE todo_id='$todoid';)
//     	WHERE todo_id='$todoid'";
//     	mysqli_multi_query($link, $sql1);




// 	UPDATE T1,T2
// INNER JOIN T2 ON T1.C1 = T2.C1
// SET T1.C2 = T2.C2,
//       T2.C3 = expr
// WHERE condition

	}  


?>

<!DOCTYPE html>
<html>
<head>


<script type="text/javascript">
			$(document).ready(function () {
				$('.dateone').datetimepicker();
				$('.datetwo').datetimepicker();
			});
	</script>
	<style type="text/css">
			.ui-datepicker { font-size:8pt !important}
	</style>



	<style>
    select {
        width: 150px;
            }
    select:focus {
        min-width: 150px;
        width: auto;
    }    
</style>
</head>
<body style="background-color:#b899c2;">
<?php

	// $query="SELECT  title.title_name FROM title inner join todo 
	// on todo.title_id=title.title_id where todo.todo_id='$todoid';";
	$query="SELECT title_id,title_name FROM title";
	// echo $query;die();
	$result= mysqli_query($link,$query);
	// echo $result;die();
?>
<form action="update_todo.php" method="post">
<h1 align="center">Title Insert Page</h1>
	<table align="center" width="50%">

	
		<tr>

		<td><label>Title Name</label></td>
		<td>	
		<?php

	// $query="SELECT  title.title_name FROM title inner join todo 
	// on todo.title_id=title.title_id where todo.todo_id='$todoid';";
	$query="SELECT title_id,title_name FROM title";
	// echo $query;die();
	$result= mysqli_query($link,$query);
	// echo $result;die();
	?>



		<select name="txttitlename" id="txttitlename"  
		value=".$tn=isset($data['title_name'])?$_POST['title_name']:''.">

		<option value='".$_POST['title_name']."' disabled selected>Select One</option>";



	<?php
	
	while ($data=mysqli_fetch_array($result)) {
		
	?>
			
			<option value="<?php echo $data['title_id'];?>" selected>
			<?php echo $data['title_name'];?>
			</option>
		
		
			 
	<?php } ?> 
	
		</select>
		</td>

		</tr>
		

	



		<tr>

			<td><label>Todo Name</label></td>
			<td><input type="text" name="txttodoname" id="txttodoname" 
			value="<?php echo $row['todo_name'];?>"></td>

		</tr>

		<tr>
		
			<td><label>Start Date</label></td>
			<td><input type="text" name="txtstartdate" id="txtstartdate" class="dateone"
			value="<?php echo $row['start_date'];?>" ></td>

		</tr>

		<tr>

			<td><label>End Date</label></td>
			<td><input type="text" name="txtenddate" id="txtenddate" class="datetwo"
			value="<?php echo $row['end_date'];?>" ></td>

		</tr>

		<tr>

		<td><label>Background Color</label></td>

		<td>

		<input type="radio" name="color" id="color" value="pink" 
		<?php if ($row['bg_color'] == 'pink') echo 'checked="checked"' ; ?> > Pink
		<input type="radio" name="color" id="color" value="blue"
		<?php if ($row['bg_color'] == 'blue') echo 'checked="checked"' ; ?> > Blue
		<input type="radio" name="color" id="color" value="orange" 
		<?php if ($row['bg_color'] == 'orange') echo 'checked="checked"' ; ?> > Orange
		<input type="radio" name="color" id="color" value="grey" 
		<?php if ($row['bg_color'] == 'grey') echo 'checked="checked"' ; ?> > Grey
		<input type="radio" name="color" id="color" value="green" 
		<?php if ($row['bg_color'] == 'green') echo 'checked="checked"' ; ?> > Green
		<input type="hidden" id="color" name="color" value="<?php echo $row['bg_color'];?>" />
		
		</td>

		</tr>

	<tr>
			<td></td>

			<td><input style="margin-right: 40px" type="submit" name="btnup" id="btnup" value="Update">

			<input style="margin-right: 40px" type="button" value="Back" 
			onclick="history.back()"></td>

			<td></td>

		</tr>
	</table>
	


</form>

</body>
<script type="text/javascript">

	$("#txttodoname,#txtstartdate,#txtenddate").keypress(function(e) {
	  //Enter key
	  if (e.which == 13) {
		return false;
	  }
	});
</script>
</html>