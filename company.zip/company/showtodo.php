<?php
include("config.php");

session_start();
if (!isset($_SESSION['login_id'])) {
header('Location: login.php');
}
$user_id=$_SESSION['login_id'];
if(isset($_POST['btndelete'])){

	$checkbox = isset($_POST['check'])?$_POST['check']:'';
	// print_r($checkbox) ;die();
		for($i=0;$i<count($checkbox);$i++){

			$arr_check= implode(',', $checkbox);
			// echo $arr_check;die();
			$query="UPDATE todo SET delete_flag=1 WHERE todo_id in(" .$arr_check. ")";
			// echo $query;die();
			if(mysqli_query($link,$query)){
				$success_message= "Deleted successfully.";
			}else{
				echo "Select checkbox to delete."; 
			} 
					
		}
	
	
}?>

<!DOCTYPE html>
<html>
<head>
	<title></title>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<style type="text/css">

	#bgg{
		width:100px;
		margin-left: 60px;
		padding-left: 50px;
		margin-top: 5px;
		margin-bottom: 5px;
		padding-right: -100px;
	}
</style>
	
</head>
<body style="background-color:#02d5fa;">
<form action="showtodo.php" method="post">
<h1 align="center">Show Todo Page</h1>
	<table align="center">
		<tr>

			<td><label>Title Name</label></td>
			<td><input type="text" name="txttitle" id="txttitle" placeholder="fill title name"></td>

			<td><label>Start Date</label></td>
			<td><input type="date" name="txtsdate" id="txtsdate"></td>

			<td><label>End Date</label></td>
			<td><input type="date" name="txtedate" id="txtedate"></td>

			<td><input type="submit" name="btnsearchh" id="btnsearchh" value="Search"></td>

			<td><a href="showtodo.php"><input type="button" name="btnclear" id="btnclear" value="Clear"></a></td>

			<td><a href="insert_todo_page.php"><input type="button" name="btninsert" id="btninsert" value="Insert"></a></td>

			<td><input type="submit" name="btndelete" id="btndelete" value="Delete"></td>

			<td><input type="button" value="Back" onclick="history.back()"></td>

		</tr>
	</table>

	<br>

	<?php

	if (isset($_POST["btnsearchh"])) {
		$ttitle=$_POST["txttitle"];


		if ($ttitle!="") {?>

		<table border="1" width="100%">

		<tr>
			<th>
				<input type="checkbox" name="name1" id="checkall"/>
			</th>
			<th>No</th>
			<th>Title Name</th>
			<th>Todo Name</th>
			<th>Start</th>
			<th>End</th>
			<th>Create User</th>
			
		</tr>

		<?php

			$query="Select todo.todo_id,title.title_name,todo.todo_name,todo.start_date,todo.end_date,todo.bg_color,title.create_user from todo INNER JOIN title on title.title_id=todo.title_id where title.title_name LIKE '%$ttitle%' where todo.delete_flag=0";
			// echo $query;die();
			$result= mysqli_query($link,$query);

			while ($data=mysqli_fetch_array($result)) {
		?>
				<tr>
					<td>
						<div >

					    	<input type="checkbox" name='check[]' id="checkItem" class="checkbox" value='<?php echo $data['todo_id'];?>'  />
					  

						</div>	
					</td>
					<td class="todoid"><?php echo $data['todo_id'];?></td>
					<td class="titlename"><?php echo $data['title_name'];?></td>
					<td class="todoname" onclick='update(<?php echo $id;?>);'>
					<span style='background-color:
					<?php echo $color;?>'> 
						<div id="bgg" style="background-color:<?php echo $data['bg_color'];?>">
						<span style='background-color:<?php echo $color;?>'> 
							<label style="cursor: pointer;" class="toname"><a href="update_todo_tr.php?todoid=<?php echo $data['todo_id'];?>"><?php echo $data['todo_name'];?></a></label>
						</span>
						</div>
					</td>
					<td class="sdate"><?php echo $data['start_date'];?></td>
					<td class="edate"><?php echo $data['end_date'];?></td>
					<td class="cuser"><?php echo $data['create_user'];?></td>
				</tr>




			
			<?php } ?>


	
	</table>
			

	<?php	} else {?>


	<table border="1" width="100%">

		<tr>
			<th>
				<input type="checkbox" name="name1" id="checkall"/>
			</th>
			<th>No</th>
			<th>Title Name</th>
			<th>Todo Name</th>
			<th>Start</th>
			<th>End</th>
			<th>Create User</th>
			
		</tr>

		<?php

			$query="Select todo.todo_id,title.title_name,todo.todo_name,todo.start_date,todo.end_date,todo.bg_color,title.create_user from todo INNER JOIN title on title.title_id=todo.title_id where todo.delete_flag=0";
			$result= mysqli_query($link,$query);

			while ($data=mysqli_fetch_array($result)) {
		?>
				<tr>
					<td>
						<div >

					    	<input type="checkbox" name='check[]' id="checkItem" class="checkbox" value='<?php echo $data['todo_id'];?>'/>
					  

						</div>	
					</td>
					<td class="todoid"><?php echo $data['todo_id'];?></td>
					<td class="titlename"><?php echo $data['title_name'];?></td>
						<td class="todoname" onclick='update(<?php echo $id;?>);'>
					<span style='background-color:
					<?php echo $color;?>'> 
						<div id="bgg" style="background-color:<?php echo $data['bg_color'];?>">
						<span style='background-color:<?php echo $color;?>'> 
							<label style="cursor: pointer;" class="toname"><a href="update_todo_tr.php?todoid=<?php echo $data['todo_id'];?>"><?php echo $data['todo_name'];?></a></label>
						</span>
						</div>
					</td>
					<td class="sdate"><?php echo $data['start_date'];?></td>
					<td class="edate"><?php echo $data['end_date'];?></td>
					<td class="cuser"><?php echo $data['create_user'];?></td>
				</tr>




			
			<?php } ?>


	
	</table>
			
	<?php }  ?>

	<?php } else {?>


	<table border="1" width="100%">

		<tr>
			<th>
				<input type="checkbox" name="name1" id="checkall"/>
			</th>
			<th>No</th>
			<th>Title Name</th>
			<th>Todo Name</th>
			<th>Start</th>
			<th>End</th>
			<th>Create User</th>
			
		</tr>

	
		<?php

			$query="Select todo.todo_id,title.title_name,todo.todo_name,todo.start_date,todo.end_date,todo.bg_color,title.create_user from todo INNER JOIN title on title.title_id=todo.title_id where todo.delete_flag=0";
			$result= mysqli_query($link,$query);

			while ($data=mysqli_fetch_array($result)) {
		?>
				<tr>
					<td>
						<div >

					    	<input type="checkbox" name='check[]' id="checkItem" class="checkbox" value='<?php echo $data['todo_id'];?>'/>
					  

						</div>	
					</td>
					<td class="todoid"><?php echo $data['todo_id'];?></td>
					<td class="titlename"><?php echo $data['title_name'];?></td>
					<td class="todoname" onclick='update(<?php echo $id;?>);'>
					<span style='background-color:
					<?php echo $color;?>'> 
						<div id="bgg" style="background-color:<?php echo $data['bg_color'];?>">
						<span style='background-color:<?php echo $color;?>'> 
							<label style="cursor: pointer;" class="toname"><a href="update_todo_tr.php?todoid=<?php echo $data['todo_id'];?>"><?php echo $data['todo_name'];?></a></label>
						</span>
						</div>
					</td>
					<td class="sdate"><?php echo $data['start_date'];?></td>
					<td class="edate"><?php echo $data['end_date'];?></td>
					<td class="cuser"><?php echo $data['create_user'];?></td>
				</tr>




			
			<?php } ?>


	
	</table>

	<?php } ?>

</form>

<script type="text/javascript">
	$(document).ready(function(){
	// Check or Uncheck All checkboxes
		$("#checkall").change(function(){
			var checked = $(this).is(':checked');
			if(checked){
				$(".checkbox").each(function(){
				$(this).prop("checked",true);
			});
			}else{
				$(".checkbox").each(function(){
				$(this).prop("checked",false);
			});
			}
	   });
		// Changing state of CheckAll checkbox 
		$(".checkbox").click(function(){
	 
			if($(".checkbox").length == $(".checkbox:checked").length) {
			  $("#checkall").prop("checked", true);
			} else {
			  $("#checkall").removeAttr("checked");
			}
		});
	});


	function update(id){
		document.getElementById('id').value = id;//$("#id").val(id);
		document.showtodo.action = "update_todo.php"; //Setting form action to "success.php" page
		document.showtodo.submit(); // Submitting form
	}





	$(function() {
		$(this).parents('#todorow').find('input[type=checkbox]').prop('disabled', true);
	});
	$("#checkall").click(function () {
		$('input:checkbox').not(this).prop('checked', this.checked);
	});
</script>

</body>

</html>
