<?php
session_start();
if (!isset($_SESSION['login_id'])) {
header('Location: login.php');
}
$user_id=$_SESSION['login_id'];
?>

<!DOCTYPE html>
<html>
<head>
<style type="text/css">
	#form{
		text-align: center;
	}
</style>

</head>
<body style="background-color:#92bd28;">
<div id="form">
<form id="form1">
<h1>Menu Page</h1>

	
		<input type="submit" name="btntitle" id="btntitle" value="Title Page" 
		onclick="submitForm('titleshow.php')">



		<input type="submit" name="btnshow" id="btnshow" value="Show Page" 
		onclick="submitForm('showtodo.php')">
	

</form>
</div>

<script type="text/javascript">
		function submitForm(action) {
			var form = document.getElementById('form1');
				form.action = action;
					form.submit();
  }
</script>


</body>
</html>