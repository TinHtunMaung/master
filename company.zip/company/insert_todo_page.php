<?php
include("config.php");
session_start();
if (!isset($_SESSION['login_id'])) {
header('Location: login.php');
}
if(isset($_POST["btnok"])){
	$titlename=$_POST["txttitlename"];
	$todoname=$_POST["txttodoname"];
	$startdate=$_POST["txtstartdate"];


	$enddate=$_POST["txtenddate"];
	// $bkgcolor=$_POST["color"];
	if(isset($_POST['color'])){
		$radio=$_POST['color'];
		

	}
	$deleteflag=0;
	// echo $startdate;die();
	// echo $start;die();
	

	if($titlename=="" && $todoname=="" && $startdate=="" && $enddate=="" && $radio==""  ){

		echo "Please fill all field";

	}
	else if($titlename==""){
		echo "Please fill title name!";
	}
	else if($todoname==""){
		echo "Please fill todoname!";
	}

	else if($startdate==""){
		echo "Please select start date!";
	}
	else if($enddate==""){
		echo "Please fill select end date!";
	}
	else if($radio==""){
		echo "Please choose background color!";
	}

	else {

		$query1="SELECT title_id FROM title WHERE title_name ='$titlename'";
		$result=mysqli_query($link,$query1);
		$tid=mysqli_fetch_array($result);
		$titleid=$tid[0];
		$sql1="INSERT INTO todo(todo_name,start_date,end_date,bg_color,delete_flag,title_id)
		VALUES('$todoname','$startdate','$enddate','$radio','$flag',$titleid)";
		$todo_result=mysqli_multi_query($link,$sql1);
		
	}
}
?>

<!DOCTYPE html>
<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<style>
    select {
        width: 150px;
            }
    select:focus {
        min-width: 150px;
        width: auto;
    }    
</style>
</head>
<body style="background-color:#18f500;">
<?php

	$query="SELECT DISTINCT title_name FROM title;";
	$result= mysqli_query($link,$query);
?>
<form action="insert_todo_page.php" method="post">
<h1 align="center">Title Insert Page</h1>
	<table align="center" width="50%">
		<tr>

		<td><label>Title Name</label></td>
		<td>

		<select name="txttitlename" id="txttitlename">

	<?php
	while ($data=mysqli_fetch_array($result)) {
	?>
			
			<option value="<?php echo $data['title_name'];?>">
			<?php echo $data['title_name'];?>
			</option>
	<?php } ?> 
		</select>
		</td>

		</tr>
		


		<tr>

			<td><label>Todo Name</label></td>
			<td><input type="text" name="txttodoname" id="txttodoname"></td>

		</tr>

		<tr>

			<td><label>Start Date</label></td>
			<td><input type="date" name="txtstartdate" id="txtstartdate"></td>

		</tr>

		<tr>

			<td><label>End Date</label></td>
			<td><input type="date" name="txtenddate" id="txtenddate"></td>

		</tr>

		<tr>

		<td><label>Background Color</label></td>

		<td>
		<input type="radio" name="color" id="color" value="pink" checked=""> Pink
		<input type="radio" name="color" id="color" value="blue"> Blue
		<input type="radio" name="color" id="color" value="orange"> Orange
		<input type="radio" name="color" id="color" value="Grey"> Grey
		<input type="radio" name="color" id="color" value="Green"> Green
		</td>

		</tr>
		

			<td></td>
			<td><input style="margin-right: 50px" type="submit" name="btnok" id="btnok" value="OK">

			<input style="margin-right: 50px" type="submit" name="btncancel" id="btncancel" 
			value="Cancel" onClick="window.location='http://yoursite.com/index.php';"></td>
			<td></td>


		</tr>
	</table>
	


</form>

</body>
</html>