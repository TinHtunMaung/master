<?php
include("config.php");

if(isset($_POST["btninsertt"])){
	$title=$_POST["txttitl"];
	$createuser=$_POST["txtcuser"];

	if($title=="" && $createuser==""  ){

		echo "Please fill all field!";

	}
	else if($title==""){
		echo "Please fill title name!";
	}
	else if($createuser==""){
		echo "Please fill user name!";
	}

	else {

		$sql3= "INSERT INTO title(title_name,create_user) VALUES ('$title','$createuser')";
		$result=mysqli_multi_query($link,$sql3);
		
		echo "Saved Successfully";
	}
}

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body style="background-color:#fa027a;">
<form action="title_insert_page.php" method="post">
<h1 align="center">Title Insert Page</h1>
	<table align="center">
		<tr>

			<td><label>Title</label></td>
			<td><input type="text" name="txttitl" id="txttitl"></td>
		</tr>

		<tr>

			<td><label>Create_User</label></td>
			<td><input type="text" name="txtcuser" id="txtcuser"></td>

		</tr>
			
		<tr>
			<td></td>

			<td><input style="margin-right: 40px" type="submit" name="btninsertt" id="btninsertt" value="Insert">

			<input style="margin-right: 40px" type="button" value="Back" 
			onclick="history.back()"></td>

			<td></td>

		</tr>
	</table>
</form>

</script>
</body>
</html>

